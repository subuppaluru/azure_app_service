Terraform commands to execute
=============================

terraform init

terraform plan -out main.tfplan

terraform apply main.tfplan


Clean up resources
===================

terraform plan -destroy -out main.destroy.tfplan

terraform apply main.destroy.tfplan